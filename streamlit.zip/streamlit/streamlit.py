import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Title
st.title("Alzheimer's Disease Prediction App")

# Load Data
@st.cache_data
def load_data(uploaded_file):
    if uploaded_file is not None:
        return pd.read_csv(uploaded_file)
    else:
        st.error('Please upload a valid CSV file.')
        return None

# File Upload
uploaded_file = st.file_uploader("Upload your Alzheimer's dataset (CSV)", type=['csv'])
if uploaded_file:
    df = load_data(uploaded_file)
    
    # Display Dataset
    st.subheader('Dataset Overview')
    st.write(df.head())

    # Data Visualization
    st.subheader('Data Distribution')
    selected_col = st.selectbox('Select a column to visualize:', df.columns)
    fig, ax = plt.subplots()
    sns.histplot(df[selected_col], kde=True, bins=30, color='skyblue', ax=ax)
    st.pyplot(fig)

    # Model Training
    st.subheader('Model Training with Decision Tree')
    if st.button('Train Model'):
        X = df.drop('Diagnosis', axis=1)
        y = df['Diagnosis']
        
        # Preprocessing
        le = LabelEncoder()
        y = le.fit_transform(y)
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        model = DecisionTreeClassifier( random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        
        acc = accuracy_score(y_test, predictions)
        st.write(f'Accuracy: {acc:.2f}')
        st.write('Classification Report:')
        st.text(classification_report(y_test, predictions))
        
        cm = confusion_matrix(y_test, predictions)
        fig, ax = plt.subplots()
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
        st.pyplot(fig)
else:
    st.info('Please upload a dataset to proceed.')












